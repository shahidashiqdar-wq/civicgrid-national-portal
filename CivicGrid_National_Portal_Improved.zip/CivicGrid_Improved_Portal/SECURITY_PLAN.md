# CivicGrid Security & Release Plan

## Local build status

This project is a local development build. Its 200 household records are synthetic. Do not enter real household/family details or real resident phone numbers unless you have verified authority and have configured and tested the appropriate controls.

Implemented in this code package: password hashing with bcrypt-compatible bcryptjs, server-side account table, phone OTP challenge table with expiry and attempt limits, SQLite-backed express sessions, HTTP-only/SameSite cookie settings, CSRF token validation on state-changing API routes, input limits, parameterized SQL, authentication rate limiting, limited audit events, admin-only analytics/report endpoints, resident-to-linked-house scoping, and pseudonymous visitor metrics without raw IP storage.

Not yet production-ready: real SMS delivery unless provider credentials are configured; administrator MFA; HTTPS/deployment topology; formal authorization and identity/enrollment policies for real household data; secrets management; key management/encryption at rest beyond storage/volume defaults; tested backup and recovery; observability/alerting; incident response; independent penetration test; load test; legal/privacy review; and a production-grade migration/import workflow.

## Release gates before real information

1. Confirm lawful purpose, authority, privacy notice, consent/enrollment requirements, data classification, retention and correction/deletion process.
2. Decide whether residents can self-register or must receive an official invitation/verified House ID. Current self-registration is constrained to seeded synthetic House/Family pairs.
3. Configure SMS provider; use OTP expiry, rate limits and provider-side abuse monitoring; do not expose OTP codes to the browser or logs in production.
4. Implement MFA for administrators and review recovery/account takeover risks.
5. Configure HTTPS, HSTS, secure cookies, production secret management, least-privilege runtime file permissions, protected backup storage and restore tests.
6. Review CSRF, session fixation, XSS, access control, password reset, account enumeration, rate limiting, logging and dependency risks.
7. Create tamper-resistant audit logging and retention controls; never log passwords, OTP codes, tokens or full family data.
8. Perform threat modeling and independent security/penetration testing; fix findings before importing real records.
9. Define and test SLOs, RTO/RPO, peak traffic, monitoring, incident response and recovery procedures. Increase load in measured stages.
10. Obtain legal, security, data-owner and operational sign-off.

## Standards to consider

- OWASP Application Security Verification Standard: https://owasp.org/www-project-application-security-verification-standard/
- OWASP Cheat Sheets: https://cheatsheetseries.owasp.org/
- NIST Secure Software Development Framework: https://csrc.nist.gov/projects/ssdf

No application can honestly be guaranteed bug-free, unhackable, or capable of unlimited traffic. Capacity and security must be measured and tested against the actual use case and budget.
