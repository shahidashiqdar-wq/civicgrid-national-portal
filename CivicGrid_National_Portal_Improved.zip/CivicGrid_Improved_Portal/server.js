'use strict';

require('dotenv').config();
const crypto = require('node:crypto');
const path = require('node:path');
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');
const { db, writeAudit } = require('./database');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';
const sessionSecret = process.env.SESSION_SECRET;
if (isProduction && (!sessionSecret || sessionSecret.length < 32)) {
  throw new Error('Production requires SESSION_SECRET with at least 32 characters.');
}
const effectiveSessionSecret = sessionSecret || crypto.randomBytes(48).toString('hex');
if (!sessionSecret && !isProduction) console.warn('Local session secret generated for this run. Configure SESSION_SECRET in .env for stable local sessions.');

if (isProduction) app.set('trust proxy', 1);
app.disable('x-powered-by');

const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'", 'https://unpkg.com'],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://unpkg.com'],
  imgSrc: ["'self'", 'data:', 'https://images.unsplash.com', 'https://server.arcgisonline.com'],
  connectSrc: ["'self'", 'https://server.arcgisonline.com'],
  fontSrc: ["'self'", 'data:', 'https://unpkg.com'],
  objectSrc: ["'none'"],
  baseUri: ["'self'"],
  formAction: ["'self'"],
  frameAncestors: ["'none'"]
};
if (isProduction) cspDirectives.upgradeInsecureRequests = [];
app.use(helmet({ contentSecurityPolicy: { directives: cspDirectives }, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '10kb', strict: true }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// SQLite-backed session store keeps sessions across a local server restart.
class SQLiteSessionStore extends session.Store {
  constructor(database) {
    super();
    this.database = database;
    this.getStatement = database.prepare('SELECT sess, expires_at FROM civicgrid_sessions WHERE sid = ?');
    this.setStatement = database.prepare(`INSERT INTO civicgrid_sessions (sid, sess, expires_at) VALUES (?, ?, ?)
      ON CONFLICT(sid) DO UPDATE SET sess = excluded.sess, expires_at = excluded.expires_at`);
    this.destroyStatement = database.prepare('DELETE FROM civicgrid_sessions WHERE sid = ?');
    this.touchStatement = database.prepare('UPDATE civicgrid_sessions SET expires_at = ? WHERE sid = ?');
  }
  get(sid, callback) {
    try {
      const row = this.getStatement.get(sid);
      if (!row) return callback(null, null);
      if (row.expires_at <= Date.now()) {
        this.destroyStatement.run(sid);
        return callback(null, null);
      }
      return callback(null, JSON.parse(row.sess));
    } catch (error) { return callback(error); }
  }
  set(sid, sess, callback = () => {}) {
    try {
      const expiry = sess.cookie && sess.cookie.expires
        ? new Date(sess.cookie.expires).getTime()
        : Date.now() + (sess.cookie && Number(sess.cookie.maxAge) ? Number(sess.cookie.maxAge) : 30 * 60 * 1000);
      this.setStatement.run(sid, JSON.stringify(sess), expiry);
      callback(null);
    } catch (error) { callback(error); }
  }
  destroy(sid, callback = () => {}) {
    try { this.destroyStatement.run(sid); callback(null); } catch (error) { callback(error); }
  }
  touch(sid, sess, callback = () => {}) {
    try {
      const expiry = sess.cookie && sess.cookie.expires
        ? new Date(sess.cookie.expires).getTime()
        : Date.now() + (sess.cookie && Number(sess.cookie.maxAge) ? Number(sess.cookie.maxAge) : 30 * 60 * 1000);
      this.touchStatement.run(expiry, sid);
      callback(null);
    } catch (error) { callback(error); }
  }
}

app.use(session({
  name: 'civicgrid.sid',
  secret: effectiveSessionSecret,
  store: new SQLiteSessionStore(db),
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProduction,
    maxAge: 30 * 60 * 1000,
    path: '/'
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many attempts. Wait 15 minutes and try again.' } });
const otpLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 5, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many verification attempts. Please wait before trying again.' } });
const analyticsLimiter = rateLimit({ windowMs: 60 * 1000, limit: 90, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many requests.' } });

function csrfProtection(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (origin) {
    const expectedOrigin = `${req.protocol}://${req.get('host')}`;
    if (origin !== expectedOrigin) return res.status(403).json({ error: 'Request origin was not accepted.' });
  }
  const token = req.get('x-csrf-token');
  if (!req.session || !req.session.csrfToken || typeof token !== 'string' || token !== req.session.csrfToken) {
    return res.status(403).json({ error: 'Security token expired. Refresh the page and try again.' });
  }
  return next();
}
app.use('/api', csrfProtection);

// Serve the login page and portal assets from this server (never open index.html as file://).
app.use(express.static(path.join(__dirname, 'public'), { etag: true, maxAge: isProduction ? '1h' : 0 }));

function randomOtp() { return String(crypto.randomInt(0, 1000000)).padStart(6, '0'); }
function hashOtp(userId, otp) {
  return crypto.createHmac('sha256', effectiveSessionSecret).update(`${userId}:${otp}`).digest('hex');
}
function safeCompareHex(left, right) {
  if (typeof left !== 'string' || typeof right !== 'string' || left.length !== right.length) return false;
  try { return crypto.timingSafeEqual(Buffer.from(left, 'hex'), Buffer.from(right, 'hex')); } catch { return false; }
}
function normalizePhone(input) {
  let value = String(input || '').trim().replace(/[\s().-]/g, '');
  if (/^\d{10}$/.test(value)) value = `+91${value}`;
  else if (/^91\d{10}$/.test(value)) value = `+${value}`;
  return value;
}
function isValidPhone(phone) { return /^\+[1-9]\d{7,14}$/.test(phone); }
function isValidUsername(username) { return /^[A-Za-z0-9._-]{3,40}$/.test(username); }
function cleanString(value, max = 100) { return typeof value === 'string' ? value.trim().slice(0, max) : ''; }

async function deliverOtp(phone, otp) {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_FROM_NUMBER;
  if (sid && token && from) {
    const url = `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(sid)}/Messages.json`;
    const body = new URLSearchParams({ To: phone, From: from, Body: `Your CivicGrid verification code is ${otp}. It expires in 5 minutes.` });
    const response = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString('base64')}`, 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    });
    if (!response.ok) {
      const providerBody = await response.text().catch(() => '');
      console.error('SMS provider rejected OTP request:', response.status, providerBody.slice(0, 300));
      throw new Error('SMS delivery failed. Check your SMS provider configuration.');
    }
    return 'sms';
  }
  if (!isProduction && process.env.DEV_OTP_MODE === 'true') {
    console.log(`\n[CivicGrid LOCAL OTP] Phone ${phone}: ${otp} (expires in 5 minutes; local testing only)\n`);
    return 'terminal';
  }
  throw new Error('SMS delivery is not configured. Configure a supported SMS provider before requesting OTP in production.');
}

function writeOtpChallenge(userId, otp) {
  const now = Date.now();
  db.prepare(`INSERT INTO otp_challenges (user_id, otp_hash, expires_at, attempts, last_sent_at)
    VALUES (?, ?, ?, 0, ?)
    ON CONFLICT(user_id) DO UPDATE SET otp_hash = excluded.otp_hash, expires_at = excluded.expires_at, attempts = 0, last_sent_at = excluded.last_sent_at`)
    .run(userId, hashOtp(userId, otp), now + 5 * 60 * 1000, now);
}
function deviceClass(userAgent = '') {
  if (/ipad|tablet/i.test(userAgent)) return 'Tablet';
  if (/mobile|android|iphone/i.test(userAgent)) return 'Mobile';
  return 'Desktop';
}
function visitorCookieKey(req, res) {
  const cookies = String(req.headers.cookie || '').split(';');
  const pair = cookies.map((x) => x.trim()).find((x) => x.startsWith('cg_vid='));
  let visitorId = pair ? decodeURIComponent(pair.slice('cg_vid='.length)) : '';
  if (!/^[a-f0-9-]{36}$/i.test(visitorId)) {
    visitorId = crypto.randomUUID();
    res.cookie('cg_vid', visitorId, { httpOnly: true, sameSite: 'lax', secure: isProduction, maxAge: 365 * 24 * 60 * 60 * 1000, path: '/' });
  }
  return crypto.createHash('sha256').update(visitorId).digest('hex');
}
function requireAuth(req, res, next) {
  if (!req.session || !Number.isInteger(req.session.userId)) return res.status(401).json({ error: 'Please sign in to continue.' });
  const account = db.prepare('SELECT id, full_name, username, role, house_id, family_id, phone_verified FROM users WHERE id = ?').get(req.session.userId);
  if (!account || account.phone_verified !== 1) {
    return req.session.destroy(() => res.status(401).json({ error: 'Your session is no longer valid. Please sign in again.' }));
  }
  req.account = account;
  next();
}
function requireAdmin(req, res, next) {
  if (!req.account || req.account.role !== 'admin') return res.status(403).json({ error: 'Administrator permission is required for this page.' });
  next();
}
function publicUser(user) {
  return {
    id: user.id,
    fullName: user.full_name || user.username,
    username: user.username,
    role: user.role,
    houseId: user.house_id || null,
    familyId: user.family_id || null
  };
}
function publicHouse(row, includeMembers = false) {
  const h = {
    id: row.house_id, houseId: row.house_id, familyId: row.family_id,
    name: row.representative, area: row.area, street: row.street, type: row.house_type,
    status: row.status, lat: row.lat, lon: row.lon, updated: row.updated_at,
    electricity: row.electricity, water: row.water, toilet: row.toilet, road: row.road,
    landmark: row.landmark, remarks: row.remarks, dataSource: 'synthetic'
  };
  if (includeMembers) {
    try { h.members = JSON.parse(row.members_json || '[]').map((m) => ({ name: String(m[0]), age: Number(m[1]), gender: String(m[2]), occupation: String(m[3]), relation: String(m[4]) })); }
    catch { h.members = []; }
  }
  return h;
}
function getHouseForAccount(houseId, account) {
  const h = db.prepare('SELECT * FROM houses WHERE house_id = ? COLLATE NOCASE').get(houseId);
  if (!h) return null;
  if (account.role !== 'admin' && h.house_id.toLowerCase() !== String(account.house_id || '').toLowerCase()) return null;
  return h;
}
function csvCell(value) { return `"${String(value ?? '').replace(/"/g, '""')}"`; }
function visitorAlias(key) { return `Visitor ${String(parseInt(String(key).slice(0, 8), 16) % 100000).padStart(5, '0')}`; }

app.get('/api/health', (_req, res) => res.json({ status: 'ok', message: 'CivicGrid service is running' }));
app.get('/api/csrf', (req, res) => {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  res.set('Cache-Control', 'no-store');
  res.json({ csrfToken: req.session.csrfToken });
});

app.get('/api/otp/pending', (req, res) => {
  const id = req.session && req.session.pendingUserId;
  if (!Number.isInteger(id)) return res.json({ pending: false });
  const user = db.prepare('SELECT username, phone_verified FROM users WHERE id = ?').get(id);
  if (!user || user.phone_verified === 1) {
    req.session.pendingUserId = null;
    return res.json({ pending: false });
  }
  res.set('Cache-Control', 'no-store');
  return res.json({ pending: true, username: user.username });
});

app.post('/api/register', authLimiter, async (req, res) => {
  try {
    const fullName = cleanString(req.body.fullName, 80);
    const username = cleanString(req.body.username, 40).toLowerCase();
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    const houseId = cleanString(req.body.houseId, 80).toUpperCase();
    const familyId = cleanString(req.body.familyId, 80).toUpperCase();
    const phone = normalizePhone(req.body.phone);

    if (!fullName || !isValidUsername(username) || password.length < 12 || password.length > 72 || !isValidPhone(phone) || !houseId || !familyId) {
      return res.status(400).json({ error: 'Check all fields. Usernames need 3–40 characters, passwords 12–72 characters, and phone numbers must be valid international-format numbers.' });
    }
    const house = db.prepare('SELECT id FROM houses WHERE house_id = ? COLLATE NOCASE AND family_id = ? COLLATE NOCASE').get(houseId, familyId);
    if (!house) return res.status(400).json({ error: 'That House ID and Family ID pair was not found in the current record set. Use a matching synthetic record for local testing.' });
    if (db.prepare('SELECT id FROM users WHERE username = ? COLLATE NOCASE OR phone = ?').get(username, phone)) {
      return res.status(409).json({ error: 'That username or phone number is already registered. Use the login page for an existing account.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const result = db.prepare(`INSERT INTO users (full_name, username, password_hash, house_id, family_id, phone, phone_verified, role)
      VALUES (?, ?, ?, ?, ?, ?, 0, 'resident')`).run(fullName, username, passwordHash, houseId, familyId, phone);
    const userId = Number(result.lastInsertRowid);
    const otp = randomOtp();
    writeOtpChallenge(userId, otp);
    req.session.pendingUserId = userId;
    writeAudit('registration_started', userId, 'Resident account created; verification pending');
    try {
      const method = await deliverOtp(phone, otp);
      return res.status(202).json({ pendingVerification: true, username, message: method === 'terminal' ? 'Account details saved. For local development, copy the 6-digit OTP from the VS Code server terminal.' : 'Verification code sent to your phone.' });
    } catch (deliveryError) {
      console.error('OTP delivery failed:', deliveryError.message);
      return res.status(503).json({ pendingVerification: true, username, error: 'Account was saved but the OTP could not be delivered. Check SMS settings, then request a new code.' });
    }
  } catch (error) {
    if (String(error.code || '').includes('SQLITE_CONSTRAINT')) return res.status(409).json({ error: 'That username or phone number is already registered.' });
    console.error('Registration error:', error.message);
    return res.status(500).json({ error: 'Account creation could not be completed.' });
  }
});

app.post('/api/resend-otp', otpLimiter, async (req, res) => {
  try {
    const pendingUserId = req.session.pendingUserId;
    if (!Number.isInteger(pendingUserId)) return res.status(400).json({ error: 'Start account creation again or return to the login page.' });
    const user = db.prepare('SELECT id, username, phone, phone_verified FROM users WHERE id = ?').get(pendingUserId);
    if (!user || user.phone_verified === 1) return res.status(400).json({ error: 'No pending verification was found.' });
    const old = db.prepare('SELECT last_sent_at FROM otp_challenges WHERE user_id = ?').get(user.id);
    if (old && Date.now() - old.last_sent_at < 30 * 1000) return res.status(429).json({ error: 'Please wait 30 seconds before requesting another code.' });
    const otp = randomOtp();
    writeOtpChallenge(user.id, otp);
    const method = await deliverOtp(user.phone, otp);
    writeAudit('otp_resent', user.id, 'Verification code resent');
    res.json({ message: method === 'terminal' ? 'New code created. Check the VS Code server terminal.' : 'A new verification code was sent.' });
  } catch (error) {
    console.error('OTP resend failed:', error.message);
    res.status(503).json({ error: 'Could not send a new verification code.' });
  }
});

app.post('/api/verify-otp', otpLimiter, (req, res) => {
  const username = cleanString(req.body.username, 40).toLowerCase();
  const otp = cleanString(req.body.otp, 6);
  const userId = req.session.pendingUserId;
  if (!Number.isInteger(userId) || !isValidUsername(username) || !/^\d{6}$/.test(otp)) {
    return res.status(400).json({ error: 'Enter the 6-digit code sent for the account being created.' });
  }
  const user = db.prepare('SELECT id, username, phone_verified FROM users WHERE id = ?').get(userId);
  const challenge = db.prepare('SELECT otp_hash, expires_at, attempts FROM otp_challenges WHERE user_id = ?').get(userId);
  if (!user || user.username.toLowerCase() !== username || !challenge) return res.status(400).json({ error: 'No pending verification was found. Start account creation again.' });
  if (challenge.expires_at <= Date.now()) {
    db.prepare('DELETE FROM otp_challenges WHERE user_id = ?').run(userId);
    return res.status(400).json({ error: 'This code has expired. Request a new code.' });
  }
  if (challenge.attempts >= 5) {
    db.prepare('DELETE FROM otp_challenges WHERE user_id = ?').run(userId);
    return res.status(429).json({ error: 'Too many incorrect codes. Request a new code.' });
  }
  const expected = hashOtp(userId, otp);
  if (!safeCompareHex(challenge.otp_hash, expected)) {
    db.prepare('UPDATE otp_challenges SET attempts = attempts + 1 WHERE user_id = ?').run(userId);
    writeAudit('otp_failed', userId, 'Incorrect OTP attempt');
    return res.status(400).json({ error: 'The verification code is incorrect.' });
  }
  db.prepare('UPDATE users SET phone_verified = 1 WHERE id = ?').run(userId);
  db.prepare('DELETE FROM otp_challenges WHERE user_id = ?').run(userId);
  req.session.pendingUserId = null;
  writeAudit('otp_verified', userId, 'Phone verification completed');
  res.json({ success: true, username: user.username, message: 'Your account has been created and verified successfully. Return to Login and sign in with your new username and password.' });
});

app.post('/api/login/resend-otp', authLimiter, otpLimiter, async (req, res) => {
  try {
    const username = cleanString(req.body.username, 40).toLowerCase();
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    if (!isValidUsername(username) || !password || password.length > 72) {
      return res.status(400).json({ error: 'Enter your registered username and password.' });
    }
    const user = db.prepare('SELECT id, username, password_hash, phone, phone_verified FROM users WHERE username = ? COLLATE NOCASE').get(username);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }
    if (user.phone_verified === 1) return res.status(400).json({ error: 'This account is already verified. Sign in normally.' });
    const oldChallenge = db.prepare('SELECT last_sent_at FROM otp_challenges WHERE user_id = ?').get(user.id);
    if (oldChallenge && Date.now() - oldChallenge.last_sent_at < 30 * 1000) {
      req.session.pendingUserId = user.id;
      return res.status(429).json({ pendingVerification: true, username: user.username, error: 'Please wait 30 seconds before requesting another code.' });
    }
    const otp = randomOtp();
    writeOtpChallenge(user.id, otp);
    req.session.pendingUserId = user.id;
    const method = await deliverOtp(user.phone, otp);
    writeAudit('otp_resent_from_login', user.id, 'Verification code requested from login page');
    return res.json({ pendingVerification: true, username: user.username, message: method === 'terminal' ? 'Check the VS Code terminal for the 6-digit code.' : 'A verification code was sent.' });
  } catch (error) {
    console.error('Login OTP resend failed:', error.message);
    return res.status(503).json({ error: 'Could not send a verification code. Check SMS configuration.' });
  }
});

app.post('/api/login', authLimiter, async (req, res) => {
  try {
    const username = cleanString(req.body.username, 40).toLowerCase();
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    if (!isValidUsername(username) || password.length < 1 || password.length > 72) {
      return res.status(400).json({ error: 'Enter a valid username and password.' });
    }
    const user = db.prepare('SELECT id, full_name, username, password_hash, house_id, family_id, phone_verified, role FROM users WHERE username = ? COLLATE NOCASE').get(username);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      writeAudit('login_failed', user ? user.id : null, 'Invalid credentials');
      return res.status(401).json({ error: 'Invalid username or password.' });
    }
    if (user.phone_verified !== 1) {
      return res.status(403).json({ error: 'Phone verification is required. Finish the OTP step from account creation or resend the code.' });
    }
    req.session.regenerate((sessionError) => {
      if (sessionError) {
        console.error('Session regeneration failed:', sessionError.message);
        return res.status(500).json({ error: 'Could not create a secure login session.' });
      }
      req.session.userId = user.id;
      req.session.csrfToken = crypto.randomBytes(32).toString('hex');
      req.session.save((saveError) => {
        if (saveError) {
          console.error('Session save failed:', saveError.message);
          return res.status(500).json({ error: 'Could not save the login session.' });
        }
        writeAudit('login_success', user.id, 'Login successful');
        return res.json({ message: 'Login successful.', csrfToken: req.session.csrfToken, user: publicUser(user) });
      });
    });
  } catch (error) {
    console.error('Login error:', error.message);
    res.status(500).json({ error: 'Login could not be completed.' });
  }
});

app.get('/api/me', requireAuth, (req, res) => res.json({ user: publicUser(req.account), csrfToken: req.session.csrfToken }));
app.post('/api/logout', requireAuth, (req, res) => {
  const userId = req.account.id;
  writeAudit('logout', userId, 'User logged out');
  req.session.destroy((error) => {
    if (error) return res.status(500).json({ error: 'Could not sign out.' });
    res.clearCookie('civicgrid.sid', { httpOnly: true, sameSite: 'lax', secure: isProduction, path: '/' });
    res.json({ message: 'Signed out successfully.' });
  });
});

app.get('/api/dashboard', requireAuth, (req, res) => {
  const isAdmin = req.account.role === 'admin';
  const totalHouses = isAdmin ? db.prepare('SELECT COUNT(*) AS n FROM houses').get().n : Number(Boolean(req.account.house_id && db.prepare('SELECT 1 FROM houses WHERE house_id = ? COLLATE NOCASE').get(req.account.house_id)));
  const houseRows = isAdmin ? db.prepare('SELECT * FROM houses').all() : db.prepare('SELECT * FROM houses WHERE house_id = ? COLLATE NOCASE').all(req.account.house_id);
  const memberCount = houseRows.reduce((sum, row) => {
    try { return sum + JSON.parse(row.members_json || '[]').length; } catch { return sum; }
  }, 0);
  const statusCounts = { verified: 0, pending: 0, notVerified: 0 };
  houseRows.forEach((h) => {
    if (h.status === 'Verified') statusCounts.verified += 1;
    else if (h.status === 'Pending') statusCounts.pending += 1;
    else statusCounts.notVerified += 1;
  });
  res.json({ totalHouses, memberCount, statusCounts, houses: houseRows.slice(0, 8).map((h) => publicHouse(h)), isAdmin });
});

app.get('/api/houses', requireAuth, (req, res) => {
  const q = cleanString(req.query.q, 80);
  let rows;
  if (req.account.role === 'admin') {
    rows = q
      ? db.prepare(`SELECT * FROM houses WHERE house_id LIKE ? OR representative LIKE ? OR area LIKE ? OR street LIKE ? ORDER BY house_id LIMIT 250`)
        .all(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`)
      : db.prepare('SELECT * FROM houses ORDER BY id LIMIT 250').all();
  } else {
    rows = db.prepare('SELECT * FROM houses WHERE house_id = ? COLLATE NOCASE').all(req.account.house_id || '__none__');
    if (q) rows = rows.filter((h) => [h.house_id, h.representative, h.area, h.street].some((v) => String(v).toLowerCase().includes(q.toLowerCase())));
  }
  res.json({ houses: rows.map((h) => publicHouse(h)) });
});

app.get('/api/houses/:houseId', requireAuth, (req, res) => {
  const row = getHouseForAccount(req.params.houseId, req.account);
  if (!row) return res.status(404).json({ error: 'House record not found or not permitted for this account.' });
  res.json({ house: publicHouse(row, true) });
});

app.get('/api/families/:familyId', requireAuth, (req, res) => {
  if (req.account.role !== 'admin' && String(req.params.familyId).toLowerCase() !== String(req.account.family_id || '').toLowerCase()) {
    return res.status(403).json({ error: 'Residents can only view the Family ID linked to their account.' });
  }
  const row = db.prepare('SELECT * FROM houses WHERE family_id = ? COLLATE NOCASE').get(req.params.familyId);
  if (!row) return res.status(404).json({ error: 'Family record not found.' });
  const house = publicHouse(row, true);
  res.json({ family: { familyId: house.familyId, houseId: house.houseId, representative: house.name, area: house.area, status: house.status, members: house.members }, house });
});

app.get('/api/map-points', requireAuth, (req, res) => {
  const rows = req.account.role === 'admin'
    ? db.prepare('SELECT * FROM houses ORDER BY id').all()
    : db.prepare('SELECT * FROM houses WHERE house_id = ? COLLATE NOCASE').all(req.account.house_id || '__none__');
  res.json({ houses: rows.map((h) => publicHouse(h)) });
});

app.get('/api/reports', requireAuth, requireAdmin, (_req, res) => {
  const counts = db.prepare('SELECT status, COUNT(*) AS count FROM houses GROUP BY status').all();
  const areas = db.prepare('SELECT area, COUNT(*) AS count FROM houses GROUP BY area ORDER BY count DESC, area').all();
  const total = db.prepare('SELECT COUNT(*) AS count FROM houses').get().count;
  res.json({ total, counts, areas, generatedAt: new Date().toISOString(), dataNotice: 'Household report values are synthetic sample records.' });
});

app.post('/api/analytics/pageview', analyticsLimiter, (req, res) => {
  const allowedPages = new Set(['Login', 'Dashboard', 'House Search', 'House Details', 'Family Search', 'Household Directory', 'Location Map', 'Emergency Contacts', 'Reports Centre', 'Website Visitors', 'Security Centre', 'Settings', 'Create Account', 'OTP Verification']);
  const page = cleanString(req.body.page, 40);
  if (!allowedPages.has(page)) return res.status(400).json({ error: 'Page name is not allowed.' });
  const visitorKey = visitorCookieKey(req, res);
  db.prepare('INSERT INTO visitor_events (visitor_key, page_key, device_class, created_at) VALUES (?, ?, ?, ?)')
    .run(visitorKey, page, deviceClass(req.get('user-agent') || ''), new Date().toISOString());
  res.status(204).end();
});

app.get('/api/analytics/summary', requireAuth, requireAdmin, (_req, res) => {
  const events = db.prepare('SELECT visitor_key, page_key, device_class, created_at FROM visitor_events ORDER BY id DESC LIMIT 500').all();
  const total = db.prepare('SELECT COUNT(*) AS n FROM visitor_events').get().n;
  const unique = db.prepare('SELECT COUNT(DISTINCT visitor_key) AS n FROM visitor_events').get().n;
  const todayIso = new Date(); todayIso.setHours(0, 0, 0, 0);
  const today = db.prepare('SELECT COUNT(*) AS n FROM visitor_events WHERE created_at >= ?').get(todayIso.toISOString()).n;
  const topPages = db.prepare('SELECT page_key AS page, COUNT(*) AS count FROM visitor_events GROUP BY page_key ORDER BY count DESC, page_key LIMIT 10').all();
  const last7 = [];
  for (let i = 6; i >= 0; i -= 1) {
    const date = new Date(); date.setHours(0, 0, 0, 0); date.setDate(date.getDate() - i);
    const next = new Date(date); next.setDate(next.getDate() + 1);
    const count = db.prepare('SELECT COUNT(*) AS n FROM visitor_events WHERE created_at >= ? AND created_at < ?').get(date.toISOString(), next.toISOString()).n;
    last7.push({ date: date.toISOString().slice(0, 10), count });
  }
  const recent = events.map((event) => ({ visitor: visitorAlias(event.visitor_key), page: event.page_key, device: event.device_class, time: event.created_at }));
  res.set('Cache-Control', 'no-store');
  res.json({ total, unique, today, topPages, last7, recent, note: 'Visitor references are pseudonymous. No raw IP addresses or precise location are stored by this analytics feature.' });
});

app.get('/api/analytics/export.csv', requireAuth, requireAdmin, (_req, res) => {
  const rows = db.prepare('SELECT visitor_key, page_key, device_class, created_at FROM visitor_events ORDER BY id DESC LIMIT 10000').all();
  const header = ['Visitor reference', 'Page', 'Device', 'Date and time'];
  const body = rows.map((row) => [visitorAlias(row.visitor_key), row.page_key, row.device_class, row.created_at].map(csvCell).join(','));
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', 'attachment; filename="civicgrid-visitor-report.csv"');
  res.send([header.map(csvCell).join(','), ...body].join('\r\n'));
});

app.get('/api/audit/recent', requireAuth, requireAdmin, (_req, res) => {
  const events = db.prepare(`SELECT a.event_type AS event, a.detail, a.created_at AS time, COALESCE(u.username, 'system') AS username
    FROM audit_events a LEFT JOIN users u ON u.id = a.account_id ORDER BY a.id DESC LIMIT 100`).all();
  res.json({ events });
});

app.use('/api', (_req, res) => res.status(404).json({ error: 'API endpoint not found.' }));
app.use((error, _req, res, _next) => {
  if (error && error.type === 'entity.too.large') return res.status(413).json({ error: 'Request is too large.' });
  console.error('Unhandled request error:', error && error.message ? error.message : error);
  res.status(500).json({ error: 'Unexpected server error.' });
});

const server = app.listen(PORT, () => {
  const count = db.prepare("SELECT COUNT(*) AS n FROM houses WHERE house_id LIKE 'DNG-%'").get().n;
  console.log(`CivicGrid National Portal listening at http://localhost:${PORT}`);
  console.log(`Synthetic house records: ${count}. Database: local SQLite file.`);
  if (!isProduction && process.env.DEV_OTP_MODE === 'true') console.log('Local OTP mode ON: codes print to this terminal. No SMS is sent unless Twilio credentials are set.');
  if (!isProduction) console.log('Local development only. Do not expose this server to the public internet or enter real household data.');
});

function shutdown(signal) {
  console.log(`${signal} received; shutting down CivicGrid.`);
  server.close(() => {
    try { db.close(); } finally { process.exit(0); }
  });
  setTimeout(() => process.exit(1), 5000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
