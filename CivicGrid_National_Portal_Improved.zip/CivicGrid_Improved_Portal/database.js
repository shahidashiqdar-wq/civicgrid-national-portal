'use strict';

const path = require('node:path');
const Database = require('better-sqlite3');

const databasePath = process.env.CIVICGRID_DB_PATH || path.join(__dirname, 'civicgrid.db');
const db = new Database(databasePath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

function columnExists(table, column) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some((row) => row.name === column);
}

function ensureColumn(table, column, definition) {
  if (!columnExists(table, column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
}

db.exec(`
  CREATE TABLE IF NOT EXISTS houses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    house_id TEXT NOT NULL UNIQUE COLLATE NOCASE,
    area TEXT NOT NULL,
    family_id TEXT,
    representative TEXT NOT NULL DEFAULT 'Synthetic household representative',
    street TEXT NOT NULL DEFAULT 'Example Street',
    house_type TEXT NOT NULL DEFAULT 'Pucca House',
    status TEXT NOT NULL DEFAULT 'Pending',
    lat REAL NOT NULL DEFAULT 34.281,
    lon REAL NOT NULL DEFAULT 74.468,
    electricity TEXT NOT NULL DEFAULT 'Available',
    water TEXT NOT NULL DEFAULT 'Available',
    toilet TEXT NOT NULL DEFAULT 'Available',
    road TEXT NOT NULL DEFAULT 'Good',
    landmark TEXT NOT NULL DEFAULT 'Near local service point',
    remarks TEXT NOT NULL DEFAULT 'Synthetic example record',
    members_json TEXT NOT NULL DEFAULT '[]',
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_source TEXT NOT NULL DEFAULT 'synthetic'
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL DEFAULT '',
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    house_id TEXT NOT NULL DEFAULT '',
    family_id TEXT NOT NULL DEFAULT '',
    phone TEXT NOT NULL UNIQUE,
    phone_verified INTEGER NOT NULL DEFAULT 0 CHECK (phone_verified IN (0, 1)),
    role TEXT NOT NULL DEFAULT 'resident' CHECK (role IN ('resident', 'admin')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS otp_challenges (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    otp_hash TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_sent_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS civicgrid_sessions (
    sid TEXT PRIMARY KEY,
    sess TEXT NOT NULL,
    expires_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS visitor_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    visitor_key TEXT NOT NULL,
    page_key TEXT NOT NULL,
    device_class TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER,
    event_type TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  );

`);

// Migrate older CivicGrid prototype databases in place without deleting user records.
ensureColumn('houses', 'family_id', 'TEXT');
ensureColumn('houses', 'representative', "TEXT NOT NULL DEFAULT 'Synthetic household representative'");
ensureColumn('houses', 'street', "TEXT NOT NULL DEFAULT 'Example Street'");
ensureColumn('houses', 'house_type', "TEXT NOT NULL DEFAULT 'Pucca House'");
ensureColumn('houses', 'status', "TEXT NOT NULL DEFAULT 'Pending'");
ensureColumn('houses', 'lat', 'REAL NOT NULL DEFAULT 34.281');
ensureColumn('houses', 'lon', 'REAL NOT NULL DEFAULT 74.468');
ensureColumn('houses', 'electricity', "TEXT NOT NULL DEFAULT 'Available'");
ensureColumn('houses', 'water', "TEXT NOT NULL DEFAULT 'Available'");
ensureColumn('houses', 'toilet', "TEXT NOT NULL DEFAULT 'Available'");
ensureColumn('houses', 'road', "TEXT NOT NULL DEFAULT 'Good'");
ensureColumn('houses', 'landmark', "TEXT NOT NULL DEFAULT 'Near local service point'");
ensureColumn('houses', 'remarks', "TEXT NOT NULL DEFAULT 'Synthetic example record'");
ensureColumn('houses', 'members_json', "TEXT NOT NULL DEFAULT '[]'");
ensureColumn('houses', 'updated_at', "TEXT NOT NULL DEFAULT '2026-10-01T00:00:00.000Z'");
ensureColumn('houses', 'data_source', "TEXT NOT NULL DEFAULT 'synthetic'");
ensureColumn('users', 'full_name', "TEXT NOT NULL DEFAULT ''");
ensureColumn('users', 'role', "TEXT NOT NULL DEFAULT 'resident'");

db.exec(`
  CREATE INDEX IF NOT EXISTS idx_houses_area ON houses(area);
  CREATE INDEX IF NOT EXISTS idx_houses_family_id ON houses(family_id);
  CREATE INDEX IF NOT EXISTS idx_visitor_events_created ON visitor_events(created_at);
  CREATE INDEX IF NOT EXISTS idx_visitor_events_visitor ON visitor_events(visitor_key);
  CREATE INDEX IF NOT EXISTS idx_audit_events_created ON audit_events(created_at);
`);

const areas = ['Sector A', 'Sector B', 'Sector C', 'Sector D', 'Sector E', 'North Zone', 'South Zone', 'Central Zone', 'East Zone', 'West Zone'];
const types = ['Pucca House', 'Semi-Pucca House', 'Kachha House', 'Pucca House', 'Pucca House'];
const statuses = ['Verified', 'Verified', 'Verified', 'Pending', 'Not Verified'];
const streets = ['Main Road', 'School Street', 'Health Centre Road', 'Orchard Lane', 'Community Link Road'];
const landmarks = ['Near main road', 'Near school', 'Near community centre', 'Near health centre', 'Near local road'];
const firstNames = ['Aarav', 'Ayaan', 'Vivaan', 'Adil', 'Arman', 'Ishaan', 'Rehan', 'Kabir', 'Zoya', 'Aisha', 'Sara', 'Inaya', 'Mira', 'Anaya', 'Yusuf', 'Ibrahim', 'Hamza', 'Rayan', 'Sana', 'Meera', 'Rohit', 'Imran', 'Farah', 'Nida', 'Danish', 'Sahil', 'Amina', 'Tara', 'Sameer', 'Rizwan'];
const surnames = ['Dar', 'Bhat', 'Lone', 'Shah', 'Mir', 'Wani', 'Khan', 'Malik', 'Rather', 'Qureshi', 'Hussain', 'Ahmad', 'Raina', 'Koul', 'Mattoo', 'Sofi', 'Naik', 'Zargar', 'Sheikh', 'Jan'];
const occupations = ['Farmer', 'Teacher', 'Shopkeeper', 'Driver', 'Craft worker', 'Nurse', 'Student', 'Office worker', 'Homemaker', 'Electrician', 'Carpenter', 'Retired', 'Small business owner'];
function syntheticName(i, offset = 0) {
  return `${firstNames[(i * 7 + offset * 3) % firstNames.length]} ${surnames[(i * 11 + offset * 5) % surnames.length]}`;
}
function suffixFor(i) {
  // Retains the original project's published first/last sample IDs.
  if (i === 199) return 'HG';
  let n = i;
  if (n >= 199) n -= 1;
  return String.fromCharCode(65 + Math.floor(n / 26) % 26) + String.fromCharCode(65 + (n % 26));
}

const insertHouse = db.prepare(`
  INSERT OR IGNORE INTO houses
  (house_id, family_id, representative, area, street, house_type, status, lat, lon,
   electricity, water, toilet, road, landmark, remarks, members_json, updated_at, data_source)
  VALUES (@house_id, @family_id, @representative, @area, @street, @house_type, @status, @lat, @lon,
   @electricity, @water, @toilet, @road, @landmark, @remarks, @members_json, @updated_at, 'synthetic')
`);
const seedSyntheticHouses = db.transaction(() => {
  // Remove only the exact placeholder inserted by the earlier starter database.
  db.prepare("DELETE FROM houses WHERE house_id = 'CG-DEMO-001' AND area = 'Demo Area' AND data_source = 'synthetic'").run();
  for (let i = 1; i <= 200; i += 1) {
    const index = i - 1;
    const number = String(i).padStart(3, '0');
    const suffix = suffixFor(index);
    const houseId = `DNG-${number}-${suffix}`;
    const familyId = `FAM-DNG-${number}-${suffix}`;
    const representative = syntheticName(i);
    const members = [[representative, 28 + (i * 13) % 43, 'Male', occupations[(i - 1) % occupations.length], 'Household representative']];
    if (i % 7 !== 0) members.push([syntheticName(i, 1), 24 + (i * 7) % 25, 'Female', 'Homemaker / Worker', 'Partner']);
    if (i % 4 !== 0) members.push([syntheticName(i, 2), 8 + (i * 5) % 25, 'Male', 'Student', 'Sibling']);
    if (i % 3 !== 0) members.push([syntheticName(i, 3), 6 + (i * 3) % 22, 'Female', 'Student', 'Sibling']);
    if (i % 5 === 0) members.push([syntheticName(i, 4), 3 + (i % 10), 'Male', 'Student', 'Sibling']);
    insertHouse.run({
      house_id: houseId, family_id: familyId, representative, area: areas[index % areas.length],
      street: streets[index % streets.length], house_type: types[index % types.length], status: statuses[index % statuses.length],
      lat: 34.281 + (((i * 37) % 101) - 50) * 0.00019,
      lon: 74.468 + (((i * 53) % 101) - 50) * 0.00022,
      electricity: i % 13 === 0 ? 'Pending' : 'Available',
      water: i % 17 === 0 ? 'Pending' : 'Available',
      toilet: i % 19 === 0 ? 'Pending' : 'Available',
      road: i % 9 === 0 ? 'Fair' : 'Good',
      landmark: landmarks[index % landmarks.length],
      remarks: 'Synthetic example record. Not a verified address.',
      members_json: JSON.stringify(members),
      updated_at: new Date(Date.UTC(2026, 9, 1 + (i % 14), 9, 0, 0)).toISOString()
    });
  }
});
seedSyntheticHouses();

function writeAudit(eventType, accountId = null, detail = '') {
  db.prepare('INSERT INTO audit_events (account_id, event_type, detail, created_at) VALUES (?, ?, ?, ?)')
    .run(accountId, eventType, String(detail).slice(0, 200), new Date().toISOString());
}

module.exports = { db, databasePath, writeAudit };
