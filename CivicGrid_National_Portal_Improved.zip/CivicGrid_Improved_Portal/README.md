# CivicGrid National Portal — Improved local build

This is a **separate replacement project** based on the uploaded CivicGrid HTML/design and security plan. It keeps the blue/mountain login style and portal navigation while moving accounts, OTP challenges, sessions, household examples, visitor events and audit events to a SQLite backend.

## Important truth about this build

- The 200 house and family records are **synthetic examples**, not verified real homes, names, addresses or coordinates.
- Usernames and password hashes are stored in the local SQLite database. Passwords are never stored in plaintext.
- Account creation uses a 6-digit OTP. In development, the OTP is printed in the VS Code server terminal. **No SMS is sent** unless Twilio credentials are configured. This is intentionally not faked as a real SMS delivery.
- Website visitor reporting counts server-received page views across browsers using a pseudonymous random visitor key. It records page, timestamp and coarse device class, but not raw IP addresses or precise location and cannot identify an anonymous real person by name.
- Admin accounts are created using a local command, not a public self-service admin registration form. Admin-only reports, directory, security and visitor analytics require that role.
- This is a local development foundation, not a production authorization/security approval. Do not enter real household/family records until governance, consent, verified enrollment, SMS delivery, MFA for administrators, HTTPS, secrets, backups, security review and deployment controls are completed.
- No one can honestly guarantee “zero bugs” or “unhackable” software. This package receives syntax checks and local smoke tests; it still needs independent review and wider testing.

## Requirements

- Node.js 20 or later (Node.js 24 LTS is suitable).
- Windows with VS Code/PowerShell or Command Prompt is supported.
- Internet is optional for login and records; map tiles and the mountain background image use external hosts.

## Start it for the first time

1. Extract `CivicGrid_Improved_Portal.zip` into a **new folder**. Do not delete your old CivicGrid project.
2. Open the extracted `CivicGrid_Improved_Portal` folder in VS Code.
3. Open **Terminal → New Terminal**. Check the path ends in `CivicGrid_Improved_Portal`.
4. Install packages:

   ```powershell
   npm.cmd install
   ```

5. Initialize the local environment and SQLite database:

   ```powershell
   npm.cmd run setup
   ```

   This creates `.env` with a random local session secret and seeds the 200 synthetic records. Do not share `.env`.

6. Create your private administrator account:

   ```powershell
   npm.cmd run setup-admin
   ```

   Enter an administrator username, a strong password (12–72 characters), confirm the password, and enter the display name. The password prompt is hidden in a normal VS Code terminal. This command is for **local bootstrap only**; do not use it as production account provisioning.

7. Start the server:

   ```powershell
   npm.cmd start
   ```

8. In Chrome, open **http://localhost:3000**. Do not open `index.html` by double-clicking it or use a `file:///` address.

9. Sign in using the administrator credentials you created in step 6. Your name and role appear at the top-right.

## Test Create Account and OTP

1. Sign out or open a separate browser session, then click **Create Account**.
2. Select a matching synthetic pair, for example House ID `DNG-001-AA` and Family ID `FAM-DNG-001-AA`.
3. Create a unique username and a password of at least 12 characters. For testing, use a phone number you control only if you have configured actual SMS; otherwise use non-real test data.
4. Click **Continue to OTP verification**. In local mode, read the 6-digit code from the VS Code terminal running `npm.cmd start`.
5. Enter the OTP in the browser and click **Verify OTP**. On success, the site returns you to Login and prefills the username.
6. Sign in with the same username/password. A successful login opens the portal dashboard. The user record is saved in `civicgrid.db`.

**Important:** Local mode prints the OTP to the developer terminal. It does not text a phone. For real delivery, configure Twilio settings in `.env` (instructions below) and test with your provider's verified setup.

## Configure Twilio SMS (optional)

Add your actual provider values privately to `.env`:

```text
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_FROM_NUMBER=+1xxxxxxxxxx
```

Keep `DEV_OTP_MODE=true` only for development. Twilio may require trial-account recipient verification. Never publish `.env`, account tokens or screenshots showing secrets. Validate applicable messaging/consent rules before using real numbers.

## Useful commands

```powershell
npm.cmd run check
npm.cmd run validate-data
npm.cmd start
```

Stop the server with **Ctrl + C** in the terminal where it is running.

## Where the files are

- `public/index.html` — login, account creation, OTP view and portal shell.
- `public/styles.css` — existing blue/mountain visual language, responsive layout and card/table styles.
- `public/app.js` — UI navigation, form submission and API connection.
- `server.js` — Express APIs, SQLite-backed sessions, CSRF checks, rate limits, OTP, access checks, analytics and audit events.
- `database.js` — SQLite schema/migrations and deterministic seed for 200 synthetic houses.
- `scripts/initialize.js` — creates local `.env` and initializes/seeds the database.
- `scripts/setup-admin.js` — creates a private local administrator.
- `civicgrid.db` — created locally when setup/server starts; do not send it publicly.

## Account permissions

- **Administrator:** views all 200 synthetic records, directory, reports, visitor analytics and security/audit view.
- **Resident:** account is linked to one matching House ID/Family ID pair and can only request that linked household through the API.
- A production system must additionally require official enrollment/invitation, verified real House/Family ID assignments, policy-based permissions, MFA for administrators, review of emergency access, data-retention controls and independent security testing.

## Replace synthetic records later

Do not replace seed data by typing real personal details into source code. Design and approve a controlled import process first: a verified data source, data owner/authority, lawful purpose, resident notices/consent where applicable, validation, import audit trail, access policy, backup/restore test, retention and correction/deletion process. The current app deliberately has **no public bulk-import endpoint**.

## Visitor analytics & privacy

Analytics uses a random visitor cookie and stores a hash of that key, page name, coarse device class and UTC timestamp. It does not store raw IP addresses, full browser user-agent strings or exact location. Visitor references are pseudonymous aliases, not a verified name or proof of a person's identity. Visitors should be notified through a privacy notice and the retention period should be configured before public deployment.

## Security status

The build uses password hashing, short-lived HTTP-only session cookies, SQLite-backed sessions, CSRF token checks on state-changing API calls, security headers, rate limits on authentication/OTP, input validation, parameterized SQL, admin-only analytics and a limited audit log. These controls are **not a guarantee of production security**. Production deployment still needs HTTPS, a stable managed secret, an SMS provider, administrator MFA, dependency/audit review, encrypted backups, monitoring, operational procedures and independent testing. Do not label the service “unhackable.”
