'use strict';

require('dotenv').config();
const { db, databasePath } = require('../database');
try {
  const summary = db.prepare("SELECT COUNT(*) AS total, COUNT(DISTINCT house_id) AS unique_ids FROM houses WHERE house_id LIKE 'DNG-%'").get();
  const first = db.prepare("SELECT house_id, family_id FROM houses WHERE house_id = 'DNG-001-AA'").get();
  const last = db.prepare("SELECT house_id, family_id FROM houses WHERE house_id = 'DNG-200-HG'").get();
  const unmatched = db.prepare("SELECT COUNT(*) AS count FROM houses WHERE house_id LIKE 'DNG-%' AND (family_id IS NULL OR family_id = '')").get().count;
  console.log(`Database: ${databasePath}`);
  console.log(`House records: ${summary.total}; unique House IDs: ${summary.unique_ids}`);
  console.log(`First expected record: ${first ? `${first.house_id} / ${first.family_id}` : 'MISSING'}`);
  console.log(`Last expected record: ${last ? `${last.house_id} / ${last.family_id}` : 'MISSING'}`);
  console.log(`Records missing Family ID: ${unmatched}`);
  if (summary.total !== 200 || summary.unique_ids !== 200 || !first || !last || unmatched !== 0) {
    console.error('Validation failed. Do not import real information.');
    process.exitCode = 1;
  } else {
    console.log('Synthetic record validation passed.');
  }
} finally {
  db.close();
}
