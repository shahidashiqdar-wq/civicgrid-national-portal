'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.join(__dirname, '..');
const envPath = path.join(root, '.env');

if (!fs.existsSync(envPath)) {
  const env = [
    'NODE_ENV=development',
    'PORT=3000',
    `SESSION_SECRET=${crypto.randomBytes(48).toString('hex')}`,
    'DEV_OTP_MODE=true',
    '',
    '# Optional SMS provider settings (Twilio). Keep these secrets private.',
    'TWILIO_ACCOUNT_SID=',
    'TWILIO_AUTH_TOKEN=',
    'TWILIO_FROM_NUMBER=',
    ''
  ].join('\n');
  fs.writeFileSync(envPath, env, { flag: 'wx', mode: 0o600 });
  console.log('Created .env with a random local session secret.');
} else {
  let existing = fs.readFileSync(envPath, 'utf8');
  const match = existing.match(/^SESSION_SECRET=(.*)$/m);
  const configuredSecret = match ? match[1].trim() : '';
  if (!configuredSecret || configuredSecret.length < 32 || /replace-with|change-this/i.test(configuredSecret)) {
    const replacement = `SESSION_SECRET=${crypto.randomBytes(48).toString('hex')}`;
    if (match) existing = existing.replace(/^SESSION_SECRET=.*$/m, replacement);
    else existing = `${existing.replace(/\s*$/, '')}\n${replacement}\n`;
    fs.writeFileSync(envPath, existing, { mode: 0o600 });
    console.log('Replaced a missing or placeholder SESSION_SECRET with a random secret.');
  } else {
    console.log('Existing .env found with a configured session secret; leaving it unchanged.');
  }
}
require('dotenv').config({ path: envPath });
const { db, databasePath } = require('../database');
const count = db.prepare("SELECT COUNT(*) AS count FROM houses WHERE house_id LIKE 'DNG-%'").get().count;
console.log(`Database initialized: ${databasePath}`);
console.log(`Synthetic house records available: ${count} (target: 200).`);
console.log('Local OTP mode is enabled. Test OTP codes will appear only in this terminal until an SMS provider is configured.');
db.close();
