'use strict';

require('dotenv').config();
const readline = require('node:readline');
const bcrypt = require('bcryptjs');
const { db, writeAudit } = require('../database');

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(question, (answer) => { rl.close(); resolve(answer.trim()); }));
}

function askHidden(question) {
  return new Promise((resolve, reject) => {
    const input = process.stdin;
    if (!input.isTTY || typeof input.setRawMode !== 'function') {
      ask(`${question} (input may be visible): `).then(resolve, reject);
      return;
    }
    process.stdout.write(question);
    let value = '';
    const onData = (chunk) => {
      const s = chunk.toString('utf8');
      for (const ch of s) {
        if (ch === '\u0003') { input.setRawMode(false); input.pause(); input.removeListener('data', onData); process.stdout.write('\n'); reject(new Error('Cancelled')); return; }
        if (ch === '\r' || ch === '\n') {
          input.setRawMode(false); input.pause(); input.removeListener('data', onData); process.stdout.write('\n'); resolve(value); return;
        }
        if (ch === '\u007f' || ch === '\b') { value = value.slice(0, -1); continue; }
        if (ch >= ' ') value += ch;
      }
    };
    input.setRawMode(true); input.resume(); input.setEncoding('utf8'); input.on('data', onData);
  });
}

(async () => {
  try {
    const usernameInput = await ask('Administrator username (letters/numbers/._-): ');
    const username = usernameInput.toLowerCase();
    if (!/^[a-z0-9._-]{3,40}$/.test(username)) throw new Error('Username must be 3–40 characters using letters, numbers, dot, underscore or hyphen.');
    const existing = db.prepare('SELECT id, role FROM users WHERE username = ? COLLATE NOCASE').get(username);
    if (existing) throw new Error('That username already exists. Choose another username; this tool does not overwrite accounts.');
    const password = await askHidden('Administrator password (12–72 characters): ');
    if (password.length < 12 || password.length > 72) throw new Error('Password must be 12–72 characters.');
    const confirm = await askHidden('Confirm password: ');
    if (password !== confirm) throw new Error('Passwords do not match.');
    const fullName = (await ask('Administrator display name: ')) || 'CivicGrid Administrator';
    const hash = await bcrypt.hash(password, 12);
    const placeholderPhone = `admin-${username}@local.invalid`;
    const result = db.prepare(`
      INSERT INTO users (full_name, username, password_hash, house_id, family_id, phone, phone_verified, role)
      VALUES (?, ?, ?, '', '', ?, 1, 'admin')
    `).run(fullName.slice(0, 80), username, hash, placeholderPhone);
    writeAudit('admin_bootstrap_created', Number(result.lastInsertRowid), 'Local CLI administrator setup');
    console.log('\nAdministrator account created. Sign in through http://localhost:3000.');
    console.log('This local bootstrap tool is not a substitute for MFA or controlled administrator provisioning in production.');
  } catch (error) {
    console.error(`Setup failed: ${error.message}`);
    process.exitCode = 1;
  } finally {
    db.close();
  }
})();
