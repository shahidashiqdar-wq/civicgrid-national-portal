'use strict';

(() => {
  const $ = (id) => document.getElementById(id);
  let csrfToken = '';
  let currentUser = null;
  let selectedHouseId = null;
  let currentPage = 'dashboard';
  let mapInstances = [];
  let pendingUsername = '';
  let toastTimer = null;

  const pageLabels = {
    dashboard: 'Dashboard', houseSearch: 'House Search', details: 'House Details', familySearch: 'Family Search',
    directory: 'Household Directory', map: 'Location Map', contacts: 'Emergency Contacts', reports: 'Reports Centre',
    visitors: 'Website Visitors', security: 'Security Centre', settings: 'Settings'
  };

  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  }
  function setMessage(id, message, kind = 'error') {
    const target = $(id);
    if (!target) return;
    target.textContent = message || '';
    target.classList.toggle('success', kind === 'success');
  }
  function showToast(message, kind = 'success') {
    let toast = $('toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'toast';
      toast.className = 'toast';
      toast.setAttribute('role', 'status');
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.className = `toast ${kind === 'error' ? 'error' : kind === 'success' ? 'success' : ''}`;
    toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.add('hidden'), 5000);
  }
  async function request(url, options = {}) {
    const method = String(options.method || 'GET').toUpperCase();
    const headers = { Accept: 'application/json', ...(options.headers || {}) };
    let body = options.body;
    if (body && typeof body === 'object' && !(body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(body);
    }
    if (!['GET', 'HEAD', 'OPTIONS'].includes(method) && csrfToken) headers['X-CSRF-Token'] = csrfToken;
    const response = await fetch(url, { ...options, method, headers, body, credentials: 'same-origin', cache: 'no-store' });
    let data = null;
    if (response.status !== 204) data = await response.json().catch(() => ({ error: 'The server returned an unreadable response.' }));
    if (!response.ok && response.status === 401 && currentUser) {
      currentUser = null;
      showAuth('login');
      setMessage('loginMessage', 'Your login session expired. Please sign in again.');
    }
    return { ok: response.ok, status: response.status, data };
  }
  async function loadCsrf() {
    const result = await request('/api/csrf');
    if (!result.ok || !result.data?.csrfToken) throw new Error(result.data?.error || 'Unable to initialize the security token.');
    csrfToken = result.data.csrfToken;
  }
  function showAuth(which) {
    $('authShell').classList.remove('hidden');
    $('appShell').classList.add('hidden');
    $('logoutBtn').classList.add('hidden');
    $('topStatus').textContent = 'Secure access';
    $('loginForm').classList.toggle('hidden', which !== 'login');
    $('registerPanel').classList.toggle('hidden', which !== 'register');
    $('otpPanel').classList.toggle('hidden', which !== 'otp');
    if (which === 'login') $('username').focus();
    if (which === 'register') $('regFullName').focus();
    if (which === 'otp') $('otpCode').focus();
  }
  function applyUser(user) {
    currentUser = user;
    $('authShell').classList.add('hidden');
    $('appShell').classList.remove('hidden');
    $('logoutBtn').classList.remove('hidden');
    $('topStatus').textContent = `${user.fullName || user.username} · ${user.role === 'admin' ? 'Administrator' : 'Resident'}`;
    document.querySelectorAll('[data-admin-only]').forEach((node) => node.classList.toggle('hidden', user.role !== 'admin'));
    render('dashboard');
  }
  function statusBadge(value) {
    const status = String(value || 'Pending');
    const cls = status === 'Verified' ? 'status-verified' : status === 'Pending' ? 'status-pending' : 'status-not-verified';
    return `<span class="status ${cls}">${esc(status)}</span>`;
  }
  function pageHead(title, description, right = '') {
    return `<div class="head"><div><h2>${esc(title)}</h2><p class="muted">${esc(description)}</p></div>${right}</div>`;
  }
  function houseTable(houses) {
    if (!houses.length) return '<div class="empty-state">No matching household record was found.</div>';
    return `<div class="tablewrap"><table><thead><tr><th>House ID</th><th>Representative</th><th>Area / Locality</th><th>House Type</th><th>Record status</th><th>Action</th></tr></thead><tbody>${houses.map((h) => `<tr><td><b>${esc(h.houseId || h.id)}</b><div class="streetline">${esc(h.familyId || '')}</div></td><td>${esc(h.name)}</td><td>${esc(h.area)}<div class="streetline">${esc(h.street)}</div></td><td>${esc(h.type)}</td><td>${statusBadge(h.status)}</td><td><button type="button" class="btn primary" data-house-id="${esc(h.houseId || h.id)}">View details</button></td></tr>`).join('')}</tbody></table></div>`;
  }
  async function recordPageView(page) {
    try { await request('/api/analytics/pageview', { method: 'POST', body: { page } }); } catch { /* analytics must never block portal use */ }
  }
  function disposeMaps() {
    mapInstances.forEach((map) => { try { map.remove(); } catch { /* ignore stale maps */ } });
    mapInstances = [];
  }
  function drawSimpleMapFallback(element, houses) {
    element.innerHTML = `<div class="member"><strong>Location preview</strong><p class="muted">Map tiles are unavailable without an internet connection. The points below are illustrative synthetic coordinates, not verified addresses.</p><div class="bar-list">${houses.slice(0, 8).map((h) => `<div class="bar-item"><span>${esc(h.houseId)}</span><span class="bar-track"><span class="bar-fill" style="display:block;width:${20 + (Math.abs(Math.round((Number(h.lat) || 34) * 1000)) % 75)}%"></span></span><span>${esc(h.area)}</span></div>`).join('')}</div></div>`;
  }
  function initMap(elementId, houses) {
    const element = $(elementId);
    if (!element) return;
    if (!window.L || !houses.length) { drawSimpleMapFallback(element, houses); return; }
    const map = window.L.map(elementId, { scrollWheelZoom: false }).setView([34.281, 74.468], 13);
    window.L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      maxZoom: 18,
      attribution: 'Imagery © Esri'
    }).addTo(map);
    houses.forEach((house) => {
      const color = house.status === 'Verified' ? '#10a45b' : house.status === 'Pending' ? '#f59e0b' : '#dc2626';
      const marker = window.L.circleMarker([Number(house.lat), Number(house.lon)], { radius: 6, color: '#fff', weight: 1.5, fillColor: color, fillOpacity: .95 }).addTo(map);
      marker.bindPopup(`<b>${esc(house.houseId)}</b><br>${esc(house.name)}<br>${esc(house.area)}<br>${esc(house.street)}<br><span>Illustrative example point</span>`);
    });
    if (currentUser?.role === 'admin') {
      const pois = [
        { name: 'Community Health Point', lat: 34.2842, lon: 74.4710, color: '#dc2626' },
        { name: 'Public School Point', lat: 34.2788, lon: 74.4642, color: '#2563eb' },
        { name: 'Community Service Point', lat: 34.2820, lon: 74.4608, color: '#7c3aed' }
      ];
      pois.forEach((poi) => window.L.circleMarker([poi.lat, poi.lon], { radius: 9, color: '#fff', weight: 2, fillColor: poi.color, fillOpacity: 1 }).addTo(map).bindPopup(`<b>${esc(poi.name)}</b><br><span>Illustrative point only</span>`));
    }
    mapInstances.push(map);
    setTimeout(() => map.invalidateSize(), 120);
  }
  async function fetchHouses(query = '') {
    const url = query ? `/api/houses?q=${encodeURIComponent(query)}` : '/api/houses';
    const result = await request(url);
    if (!result.ok) throw new Error(result.data?.error || 'Could not load household records.');
    return result.data.houses || [];
  }
  async function renderDashboard() {
    const result = await request('/api/dashboard');
    if (!result.ok) { $('main').innerHTML = `<div class="notice danger">${esc(result.data?.error || 'Dashboard could not be loaded.')}</div>`; return; }
    const d = result.data;
    const h = d.houses || [];
    const mapResult = await request('/api/map-points');
    const mapHouses = mapResult.ok ? (mapResult.data.houses || []) : h;
    const statuses = d.statusCounts || {};
    $('main').innerHTML = pageHead('Dashboard', currentUser.role === 'admin' ? 'Portal overview, household records and community service status.' : 'Your household overview and linked community services.', '<span class="small-badge">LOCAL PORTAL</span>') +
      `<div class="notice warn section-gap">The 200 house records and their family details, statuses and coordinates are synthetic examples. They are not verified real household data.</div>` +
      `<div class="grid stats section-gap"><div class="card stat"><div class="stat-icon">⌂</div><strong>${Number(d.totalHouses).toLocaleString('en-IN')}</strong><span>${currentUser.role === 'admin' ? 'Synthetic household records' : 'Linked household record'}</span></div><div class="card stat"><div class="stat-icon">♧</div><strong>${Number(d.memberCount).toLocaleString('en-IN')}</strong><span>Household member examples</span></div><div class="card stat"><div class="stat-icon">✓</div><strong>${Number(statuses.verified || 0).toLocaleString('en-IN')}</strong><span>Records marked verified in sample data</span></div><div class="card stat"><div class="stat-icon">◷</div><strong>${Number(statuses.pending || 0).toLocaleString('en-IN')}</strong><span>Records pending in sample data</span></div></div>` +
      `<div class="grid cols"><section class="card"><h3>📍 Location map overview</h3><div id="dashmap" class="map"></div><p class="fine-print">Map points are synthetic illustrations. Third-party imagery requires an internet connection.</p></section><div class="grid"><section class="card"><h3>Emergency services</h3><div class="quick"><button type="button" class="call c1" data-phone="112">112<small>Emergency</small></button><button type="button" class="call c2" data-phone="101">101<small>Fire service</small></button><button type="button" class="call c3" data-phone="108">108<small>Ambulance</small></button><button type="button" class="call c4" data-phone="100">100<small>Police*</small></button></div><p class="fine-print">Call buttons open the device dialler only. Confirm local routing before relying on a number.</p></section><section class="card"><h3>Quick actions</h3><div class="actions"><button type="button" class="action a1" data-go="houseSearch">⌕ Search house</button><button type="button" class="action a2" data-go="familySearch">♧ Search family</button><button type="button" class="action a3" data-go="map">📍 Open map</button><button type="button" class="action a4" data-go="reports" ${currentUser.role !== 'admin' ? 'disabled' : ''}>▥ Reports centre</button></div></section></div></div>`;
    if (mapHouses.length) initMap('dashmap', mapHouses);
  }
  async function renderHouseSearch() {
    $('main').innerHTML = pageHead('House Search', currentUser.role === 'admin' ? 'Search across the synthetic record set by House ID, representative, area or street.' : 'Search is limited to the house linked to your account.') +
      `<section class="card"><form id="houseSearchForm"><div class="search-row"><input id="houseQuery" maxlength="80" placeholder="Enter House ID, representative, area or street"><button class="btn primary" type="submit">Search</button><button class="btn" id="clearHouseSearch" type="button">Clear</button></div></form><p class="fine-print">Synthetic examples only. Record statuses, names and addresses are not real verification evidence.</p><div id="houseResults" class="section-gap"><div class="empty-state">Loading household records…</div></div></section>`;
    async function run(query = '') {
      const results = $('houseResults'); if (!results) return;
      results.innerHTML = '<div class="empty-state">Searching…</div>';
      try { results.innerHTML = houseTable(await fetchHouses(query)); } catch (error) { results.innerHTML = `<div class="notice danger">${esc(error.message)}</div>`; }
    }
    $('houseSearchForm').addEventListener('submit', (event) => { event.preventDefault(); run($('houseQuery').value.trim()); });
    $('clearHouseSearch').addEventListener('click', () => { $('houseQuery').value = ''; run(''); });
    await run();
  }
  async function renderHouseDetails() {
    if (!selectedHouseId) { render('houseSearch'); return; }
    $('main').innerHTML = pageHead('House Details', 'Record information. Only the linked household is visible to resident accounts.') + '<div class="empty-state">Loading record…</div>';
    const result = await request(`/api/houses/${encodeURIComponent(selectedHouseId)}`);
    if (!result.ok) { $('main').innerHTML = pageHead('House Details', 'Record information.') + `<div class="notice danger">${esc(result.data?.error || 'House could not be loaded.')}</div><button type="button" class="btn" data-go="houseSearch">Back to House Search</button>`; return; }
    const h = result.data.house;
    const photoUrls = [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=900&q=80'
    ];
    const photo = photoUrls[(Number((h.houseId || '').match(/\d+/)?.[0]) || 1) % photoUrls.length];
    $('main').innerHTML = pageHead('House Details', `Household record ${h.houseId}. Record information is synthetic.` , '<button type="button" class="btn" data-go="houseSearch">← Back to Search</button>') +
      `<div class="notice warn section-gap">All details on this record are generated sample values and must not be used as a real address or verification record.</div><div class="grid cols section-gap"><section class="card"><h3>House information</h3><div class="detail"><div class="detail-label">House ID</div><b>${esc(h.houseId)}</b><div class="detail-label">Family ID</div><b>${esc(h.familyId)}</b><div class="detail-label">Representative</div><b>${esc(h.name)}</b><div class="detail-label">Area / locality</div><b>${esc(h.area)}</b><div class="detail-label">Street / road</div><b>${esc(h.street)}</b><div class="detail-label">House type</div><b>${esc(h.type)}</b><div class="detail-label">Record status</div><b>${statusBadge(h.status)}</b><div class="detail-label">Electricity</div><b>${esc(h.electricity)}</b><div class="detail-label">Water</div><b>${esc(h.water)}</b><div class="detail-label">Toilet</div><b>${esc(h.toilet)}</b><div class="detail-label">Road access</div><b>${esc(h.road)}</b><div class="detail-label">Landmark</div><b>${esc(h.landmark)}</b><div class="detail-label">Last updated</div><b>${esc(h.updated)}</b></div><p class="fine-print">${esc(h.remarks)}</p></section><section class="grid"><div class="card"><img class="photo" src="${photo}" alt="Illustrative house photograph, not the represented property" loading="lazy"><p class="fine-print">Illustrative stock photo only; it does not show this house.</p></div><div class="card"><h3>Location preview</h3><div id="housemap" class="map"></div><p class="fine-print">Coordinates are synthetic and do not identify a real household.</p><button type="button" class="btn" data-open-map="${Number(h.lat)}|${Number(h.lon)}">Open public map</button></div></section></div><section class="card section-gap"><h3>Household members</h3><div class="tablewrap"><table><thead><tr><th>Name</th><th>Age</th><th>Gender</th><th>Occupation</th><th>Relationship</th></tr></thead><tbody>${(h.members || []).map((m) => `<tr><td>${esc(m.name)}</td><td>${esc(m.age)}</td><td>${esc(m.gender)}</td><td>${esc(m.occupation)}</td><td>${esc(m.relation)}</td></tr>`).join('')}</tbody></table></div></section>`;
    initMap('housemap', [h]);
  }
  async function renderFamilySearch() {
    $('main').innerHTML = pageHead('Family Search', currentUser.role === 'admin' ? 'Find a family using its Family ID.' : 'Your account can view only its linked Family ID.') +
      `<div class="grid cols"><section class="card"><h3>♧ Family ID lookup</h3><form id="familySearchForm"><div class="field"><label for="familyQuery">Family ID</label><input id="familyQuery" maxlength="80" required placeholder="FAM-DNG-001-AA" ${currentUser.role !== 'admin' ? `value="${esc(currentUser.familyId || '')}" readonly` : ''}></div><button class="btn primary full" type="submit">Search family</button></form><p class="fine-print">Residents can only view the family linked during account creation.</p></section><section id="familyResult" class="card"><div class="empty-state">Enter a Family ID to view its record.</div></section></div>`;
    $('familySearchForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      const target = $('familyResult'); target.innerHTML = '<div class="empty-state">Searching…</div>';
      const result = await request(`/api/families/${encodeURIComponent($('familyQuery').value.trim())}`);
      if (!result.ok) { target.innerHTML = `<div class="notice danger">${esc(result.data?.error || 'Family search failed.')}</div>`; return; }
      const f = result.data.family;
      target.innerHTML = `<h3>Family record</h3><div class="detail"><div class="detail-label">Family ID</div><b>${esc(f.familyId)}</b><div class="detail-label">House ID</div><b>${esc(f.houseId)}</b><div class="detail-label">Representative</div><b>${esc(f.representative)}</b><div class="detail-label">Area</div><b>${esc(f.area)}</b><div class="detail-label">Record status</div><b>${statusBadge(f.status)}</b></div><h3 class="section-gap">Member examples</h3><div class="tablewrap"><table><thead><tr><th>Name</th><th>Age</th><th>Gender</th><th>Occupation</th><th>Relationship</th></tr></thead><tbody>${(f.members || []).map((m) => `<tr><td>${esc(m.name)}</td><td>${esc(m.age)}</td><td>${esc(m.gender)}</td><td>${esc(m.occupation)}</td><td>${esc(m.relation)}</td></tr>`).join('')}</tbody></table></div><p class="fine-print">Synthetic family examples, not real household information.</p>`;
    });
  }
  async function renderDirectory() {
    const result = await request('/api/houses');
    $('main').innerHTML = pageHead('Household Directory', 'Administrator view of the synthetic household record set.') +
      `<div class="notice warn section-gap">All records are synthetic. Access to a real household directory must be restricted and approved separately.</div><section class="card section-gap">${result.ok ? houseTable(result.data.houses || []) : `<div class="notice danger">${esc(result.data?.error || 'Directory unavailable.')}</div>`}</section>`;
  }
  async function renderMap() {
    const result = await request('/api/map-points');
    if (!result.ok) { $('main').innerHTML = pageHead('Location Map', 'Illustrative record map.') + `<div class="notice danger">${esc(result.data?.error || 'Map records unavailable.')}</div>`; return; }
    const houses = result.data.houses || [];
    $('main').innerHTML = pageHead('Location Map', 'Satellite imagery and colour-coded illustrative record points.') +
      `<div class="notice warn">All house coordinates and community service points are synthetic examples. They are not verified addresses or real service locations.</div><section class="card section-gap"><h3>🛰️ Location map</h3><div id="fullmap" class="map large"></div><div class="mapkey section-gap"><span><i class="legenddot" style="background:#10a45b"></i>Record marked verified</span><span><i class="legenddot" style="background:#f59e0b"></i>Pending</span><span><i class="legenddot" style="background:#dc2626"></i>Not verified</span></div><p class="fine-print">Map imagery requires an internet connection. The pins are not real household locations.</p></section>`;
    initMap('fullmap', houses);
  }
  function renderContacts() {
    $('main').innerHTML = pageHead('Emergency Contacts', 'Quick-call shortcuts for common emergency numbers.') +
      `<div class="notice warn">These buttons open your device dialler; they do not dispatch a service automatically. Confirm current local numbers and coverage before relying on them.</div><section class="card section-gap"><h3>Quick-call numbers</h3><div class="quick"><button type="button" class="call c1" data-phone="112">112<small>Emergency</small></button><button type="button" class="call c2" data-phone="101">101<small>Fire service</small></button><button type="button" class="call c3" data-phone="108">108<small>Ambulance</small></button><button type="button" class="call c4" data-phone="100">100<small>Police</small></button></div><p class="fine-print">No real household contact list is configured in this synthetic build. Add approved contacts only after official verification and consent.</p></section>`;
  }
  async function renderReports() {
    const result = await request('/api/reports');
    if (!result.ok) { $('main').innerHTML = pageHead('Reports Centre', 'Household record summaries.') + `<div class="notice danger">${esc(result.data?.error || 'Reports unavailable.')}</div>`; return; }
    const data = result.data;
    const statuses = data.counts || [];
    const areas = data.areas || [];
    const maxArea = Math.max(1, ...areas.map((x) => Number(x.count)));
    $('main').innerHTML = pageHead('Reports Centre', 'Summaries and counts generated from the stored synthetic record set.') +
      `<div class="notice warn">These are summaries of synthetic example data, not official statistics or verified household records.</div><div class="grid stats section-gap"><div class="card stat"><div class="stat-icon">⌂</div><strong>${Number(data.total).toLocaleString('en-IN')}</strong><span>House records</span></div>${statuses.map((s) => `<div class="card stat"><div class="stat-icon">▤</div><strong>${Number(s.count).toLocaleString('en-IN')}</strong><span>${esc(s.status)} status</span></div>`).join('')}</div><div class="grid cols section-gap"><section class="card"><h3>Records by area</h3><div class="bar-list">${areas.map((a) => `<div class="bar-item"><span>${esc(a.area)}</span><span class="bar-track"><span class="bar-fill" style="display:block;width:${Math.round(Number(a.count) / maxArea * 100)}%"></span></span><b>${Number(a.count)}</b></div>`).join('')}</div></section><section class="card"><h3>Report notes</h3><p>Generated: ${esc(new Date(data.generatedAt).toLocaleString())}</p><p>${esc(data.dataNotice)}</p><button id="refreshReports" class="btn primary" type="button">Refresh report</button><button id="downloadHouseCsv" class="btn" type="button">Export house records CSV</button></section></div>`;
    $('refreshReports').addEventListener('click', renderReports);
    $('downloadHouseCsv').addEventListener('click', async () => {
      const houses = await fetchHouses();
      const rows = [['House ID', 'Family ID', 'Representative', 'Area', 'Street', 'House type', 'Status'], ...houses.map((h) => [h.houseId, h.familyId, h.name, h.area, h.street, h.type, h.status])];
      downloadCsv(rows, 'civicgrid-house-records-synthetic.csv');
    });
  }
  function downloadCsv(rows, filename) {
    const csv = rows.map((row) => row.map((value) => `"${String(value ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = filename; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function drawVisitorChart(points) {
    const canvas = $('visitorChart'); if (!canvas) return;
    const width = canvas.clientWidth || 500; const height = 220; const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr; canvas.height = height * dpr;
    const ctx = canvas.getContext('2d'); ctx.scale(dpr, dpr); ctx.clearRect(0, 0, width, height);
    const max = Math.max(4, ...points.map((p) => Number(p.count)));
    const left = 30; const right = 12; const top = 14; const bottom = 32;
    const plotW = width - left - right; const plotH = height - top - bottom;
    ctx.font = '11px Segoe UI, Arial'; ctx.strokeStyle = '#dbe7f5'; ctx.fillStyle = '#62748d';
    for (let i = 0; i < 4; i += 1) { const y = top + plotH * i / 3; ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(width - right, y); ctx.stroke(); }
    ctx.strokeStyle = '#0868d7'; ctx.lineWidth = 2.5; ctx.beginPath();
    points.forEach((p, i) => { const x = left + (points.length < 2 ? plotW / 2 : i * plotW / (points.length - 1)); const y = top + plotH - Number(p.count) / max * plotH; if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); }); ctx.stroke();
    points.forEach((p, i) => { const x = left + (points.length < 2 ? plotW / 2 : i * plotW / (points.length - 1)); const y = top + plotH - Number(p.count) / max * plotH; ctx.fillStyle = '#0868d7'; ctx.beginPath(); ctx.arc(x, y, 3.5, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#62748d'; ctx.fillText(String(p.date).slice(5), x - 14, height - 10); });
  }
  async function renderVisitors() {
    const result = await request('/api/analytics/summary');
    if (!result.ok) { $('main').innerHTML = pageHead('Website Visitors', 'Server-side page view reporting.') + `<div class="notice danger">${esc(result.data?.error || 'Analytics unavailable.')}</div>`; return; }
    const data = result.data;
    $('main').innerHTML = pageHead('Website Visitors & Analytics', 'Server-side traffic counts with pseudonymous visitor references.') +
      `<div class="notice">This report records page, time, device class and a random visitor reference. It does not identify anonymous people or store raw IP addresses. Use a privacy notice and retention policy before deployment.</div><div class="grid stats section-gap"><div class="card stat"><div class="stat-icon">↗</div><strong>${Number(data.total).toLocaleString('en-IN')}</strong><span>Total page views</span></div><div class="card stat"><div class="stat-icon">👥</div><strong>${Number(data.unique).toLocaleString('en-IN')}</strong><span>Pseudonymous visitors</span></div><div class="card stat"><div class="stat-icon">◷</div><strong>${Number(data.today).toLocaleString('en-IN')}</strong><span>Page views today</span></div><div class="card stat"><div class="stat-icon">▤</div><strong>${(data.topPages || []).length}</strong><span>Pages with activity</span></div></div><section class="card section-gap"><h3>Page views over the last 7 days</h3><canvas id="visitorChart" class="analytics-chart" aria-label="Page views over the last seven days"></canvas></section><div class="grid cols section-gap"><section class="card"><h3>Most viewed pages</h3><div class="tablewrap"><table><thead><tr><th>Page</th><th>Views</th></tr></thead><tbody>${(data.topPages || []).map((x) => `<tr><td>${esc(x.page)}</td><td>${Number(x.count)}</td></tr>`).join('') || '<tr><td colspan="2">No visits recorded yet.</td></tr>'}</tbody></table></div></section><section class="card"><h3>Recent activity</h3><p class="fine-print">Visitor aliases are generated for this report and are not a verified person identity.</p><button id="refreshVisitors" class="btn primary" type="button">Refresh</button><button id="exportVisitors" class="btn" type="button">Download CSV</button></section></div><section class="card section-gap"><h3>Recent page views</h3><div class="tablewrap"><table class="visitor-table"><thead><tr><th>Visitor reference</th><th>Date &amp; time</th><th>Page</th><th>Device</th></tr></thead><tbody>${(data.recent || []).slice(0, 50).map((x) => `<tr><td>${esc(x.visitor)}</td><td>${esc(new Date(x.time).toLocaleString())}</td><td>${esc(x.page)}</td><td>${esc(x.device)}</td></tr>`).join('') || '<tr><td colspan="4">No visits recorded yet.</td></tr>'}</tbody></table></div></section>`;
    drawVisitorChart(data.last7 || []);
    $('refreshVisitors').addEventListener('click', renderVisitors);
    $('exportVisitors').addEventListener('click', async () => {
      const response = await fetch('/api/analytics/export.csv', { credentials: 'same-origin', cache: 'no-store' });
      if (!response.ok) { showToast('Could not download the report.', 'error'); return; }
      const blob = await response.blob(); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'civicgrid-visitor-report.csv'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }
  async function renderSecurity() {
    const audit = await request('/api/audit/recent');
    const events = audit.ok ? audit.data.events : [];
    $('main').innerHTML = pageHead('Security Centre', 'Current build status and required release controls.') +
      `<div class="notice danger"><b>Release status: local development only.</b> Security controls reduce risk, but this build has not had independent penetration testing, production deployment hardening or legal approval. Do not use real household data.</div><div class="grid stats section-gap"><div class="card stat"><div class="stat-icon">🔐</div><strong>Active</strong><span>Password hash + server session</span></div><div class="card stat"><div class="stat-icon">📨</div><strong>Local OTP</strong><span>Terminal in development; SMS needs provider</span></div><div class="card stat"><div class="stat-icon">🧱</div><strong>Enabled</strong><span>Input limits, CSRF checks and rate limiting</span></div><div class="card stat"><div class="stat-icon">🧪</div><strong>Required</strong><span>Independent review before production</span></div></div><div class="grid cols section-gap"><section class="card"><h3>Before production deployment</h3>${[
        'Use HTTPS/TLS and secure cookies at the public edge.',
        'Configure genuine SMS delivery and abuse controls for OTP.',
        'Add administrator MFA and controlled account provisioning.',
        'Review house/family access policies against verified enrollment data.',
        'Configure secret management and encrypted backups.',
        'Define consent, retention, deletion and incident-response processes.',
        'Run dependency scans, code review, restore tests and load tests.',
        'Obtain independent security and legal review before loading real records.'
      ].map((x) => `<div class="security-item"><span class="security-check">☐</span><div>${esc(x)}</div></div>`).join('')}</section><section class="card"><h3>Recent security events</h3><p class="fine-print">Audit events avoid passwords, OTP values, raw tokens and family details.</p><div class="tablewrap"><table><thead><tr><th>Time</th><th>Account</th><th>Event</th></tr></thead><tbody>${events.slice(0, 12).map((e) => `<tr><td>${esc(new Date(e.time).toLocaleString())}</td><td>${esc(e.username)}</td><td>${esc(e.event)}</td></tr>`).join('') || '<tr><td colspan="3">No recorded events.</td></tr>'}</tbody></table></div></section></div><section class="card section-gap"><h3>Engineering standards</h3><p>Use recognised security baselines and independent testing rather than claiming a system is unhackable.</p><p><a class="subtle-link" href="https://owasp.org/www-project-application-security-verification-standard/" target="_blank" rel="noopener noreferrer">OWASP ASVS</a> · <a class="subtle-link" href="https://cheatsheetseries.owasp.org/" target="_blank" rel="noopener noreferrer">OWASP Cheat Sheets</a> · <a class="subtle-link" href="https://csrc.nist.gov/projects/ssdf" target="_blank" rel="noopener noreferrer">NIST SSDF</a></p></section>`;
  }
  function renderSettings() {
    $('main').innerHTML = pageHead('Settings & Administration', 'Account overview and local environment information.') +
      `<div class="grid cols"><section class="card"><h3>Account profile</h3><div class="detail"><div class="detail-label">Display name</div><b>${esc(currentUser.fullName)}</b><div class="detail-label">Username</div><b>${esc(currentUser.username)}</b><div class="detail-label">Access role</div><b>${currentUser.role === 'admin' ? 'Administrator' : 'Resident'}</b><div class="detail-label">Linked House ID</div><b>${esc(currentUser.houseId || 'Administrator access')}</b><div class="detail-label">Linked Family ID</div><b>${esc(currentUser.familyId || 'Administrator access')}</b></div><p class="fine-print">Profile fields are loaded from the backend account record. Passwords are never returned to the browser.</p></section><section class="card"><h3>Portal configuration</h3><div class="field"><label>Portal name</label><input value="CivicGrid National Portal" readonly></div><div class="field"><label>Database</label><input value="Local SQLite database" readonly></div><div class="field"><label>House record source</label><input value="200 synthetic examples" readonly></div><div class="notice warn">SMS delivery, HTTPS hosting, administrator MFA, backups and formal data governance must be configured before production use.</div></section></div>`;
  }
  async function render(page) {
    if (!currentUser) { showAuth('login'); return; }
    currentPage = page;
    disposeMaps();
    document.querySelectorAll('.nav[data-page]').forEach((button) => button.classList.toggle('active', button.dataset.page === page || (page === 'details' && button.dataset.page === 'houseSearch')));
    await recordPageView(pageLabels[page] || page);
    $('main').focus({ preventScroll: true });
    try {
      if (page === 'dashboard') await renderDashboard();
      else if (page === 'houseSearch') await renderHouseSearch();
      else if (page === 'details') await renderHouseDetails();
      else if (page === 'familySearch') await renderFamilySearch();
      else if (page === 'directory') await renderDirectory();
      else if (page === 'map') await renderMap();
      else if (page === 'contacts') renderContacts();
      else if (page === 'reports') await renderReports();
      else if (page === 'visitors') await renderVisitors();
      else if (page === 'security') await renderSecurity();
      else renderSettings();
    } catch (error) {
      $('main').innerHTML = pageHead(pageLabels[page] || 'Portal', 'An error occurred while loading this section.') + `<div class="notice danger">${esc(error.message || 'Unexpected error.')}</div><button class="btn" type="button" data-go="dashboard">Return to Dashboard</button>`;
    }
  }

  $('loginForm').addEventListener('submit', async (event) => {
    event.preventDefault(); setMessage('loginMessage', 'Signing in…', 'info');
    const result = await request('/api/login', { method: 'POST', body: { username: $('username').value.trim(), password: $('password').value } }).catch((error) => ({ ok: false, data: { error: error.message } }));
    if (!result.ok) {
      if (result.status === 403 && /phone verification/i.test(result.data?.error || '')) {
        const otpResult = await request('/api/login/resend-otp', { method: 'POST', body: { username: $('username').value.trim(), password: $('password').value } }).catch((error) => ({ ok: false, data: { error: error.message } }));
        if (otpResult.data?.pendingVerification) {
          pendingUsername = otpResult.data.username || $('username').value.trim();
          $('otpUsername').value = pendingUsername; $('otpCode').value = '';
          $('otpIntro').textContent = `Verification code for ${pendingUsername}`;
          $('loginForm').classList.add('hidden'); $('otpPanel').classList.remove('hidden'); $('registerPanel').classList.add('hidden');
          setMessage('otpMessage', otpResult.data.message || otpResult.data.error || 'Enter your verification code.', otpResult.ok ? 'success' : 'error');
          recordPageView('OTP Verification');
          return;
        }
        setMessage('loginMessage', otpResult.data?.error || result.data?.error || 'Phone verification is required.');
        return;
      }
      setMessage('loginMessage', result.data?.error || 'Unable to sign in. Check your server connection.'); return;
    }
    csrfToken = result.data.csrfToken || csrfToken;
    $('password').value = '';
    setMessage('loginMessage', '', 'info');
    applyUser(result.data.user);
  });

  $('showRegister').addEventListener('click', () => { setMessage('registerMessage', ''); setMessage('loginMessage', ''); showAuth('register'); recordPageView('Create Account'); });
  $('registerBackToLogin').addEventListener('click', () => showAuth('login'));
  $('otpBackToLogin').addEventListener('click', () => showAuth('login'));

  $('registerForm').addEventListener('submit', async (event) => {
    event.preventDefault(); setMessage('registerMessage', 'Creating account and requesting verification code…', 'info');
    const result = await request('/api/register', { method: 'POST', body: {
      fullName: $('regFullName').value.trim(), username: $('regUsername').value.trim(), password: $('regPassword').value,
      houseId: $('regHouseId').value.trim(), familyId: $('regFamilyId').value.trim(), phone: $('regPhone').value.trim()
    } }).catch((error) => ({ ok: false, data: { error: error.message } }));
    if (result.data?.pendingVerification) {
      pendingUsername = result.data.username || $('regUsername').value.trim();
      $('otpUsername').value = pendingUsername;
      $('otpCode').value = '';
      setMessage('otpMessage', result.data.message || result.data.error || 'Enter the verification code.', result.ok ? 'success' : 'error');
      $('otpIntro').textContent = `Verification code for ${pendingUsername}`;
      $('registerPanel').classList.add('hidden'); $('otpPanel').classList.remove('hidden');
      recordPageView('OTP Verification');
      return;
    }
    setMessage('registerMessage', result.data?.error || 'Could not create the account.');
  });

  $('otpForm').addEventListener('submit', async (event) => {
    event.preventDefault(); setMessage('otpMessage', 'Checking verification code…', 'info');
    const result = await request('/api/verify-otp', { method: 'POST', body: { username: $('otpUsername').value.trim(), otp: $('otpCode').value.trim() } }).catch((error) => ({ ok: false, data: { error: error.message } }));
    if (!result.ok) { setMessage('otpMessage', result.data?.error || 'Could not verify the code.'); return; }
    pendingUsername = '';
    $('username').value = result.data.username || '';
    $('password').value = '';
    $('registerForm').reset(); $('otpForm').reset();
    showAuth('login');
    setMessage('loginMessage', result.data.message || 'Account verified successfully. Sign in with your new credentials.', 'success');
    $('password').focus();
  });

  $('resendOtp').addEventListener('click', async () => {
    setMessage('otpMessage', 'Requesting a new code…', 'info');
    const result = await request('/api/resend-otp', { method: 'POST', body: {} }).catch((error) => ({ ok: false, data: { error: error.message } }));
    setMessage('otpMessage', result.data?.message || result.data?.error || (result.ok ? 'A new code was requested.' : 'Could not resend the code.'), result.ok ? 'success' : 'error');
  });

  $('logoutBtn').addEventListener('click', async () => {
    const result = await request('/api/logout', { method: 'POST', body: {} });
    currentUser = null; csrfToken = '';
    await loadCsrf().catch(() => {});
    showAuth('login'); $('password').value = '';
    if (result.ok) showToast('You have signed out.', 'success');
  });

  document.querySelectorAll('.nav[data-page]').forEach((button) => button.addEventListener('click', () => {
    if (button.dataset.adminOnly !== undefined && currentUser?.role !== 'admin') return showToast('Administrator permission is required.', 'error');
    render(button.dataset.page);
  }));
  $('main').addEventListener('click', (event) => {
    const houseButton = event.target.closest('[data-house-id]');
    if (houseButton) { selectedHouseId = houseButton.dataset.houseId; render('details'); return; }
    const goButton = event.target.closest('[data-go]');
    if (goButton) { render(goButton.dataset.go); return; }
    const phoneButton = event.target.closest('[data-phone]');
    if (phoneButton) { window.location.href = `tel:${phoneButton.dataset.phone}`; return; }
    const mapButton = event.target.closest('[data-open-map]');
    if (mapButton) {
      const [lat, lon] = mapButton.dataset.openMap.split('|').map(Number);
      if (Number.isFinite(lat) && Number.isFinite(lon)) window.open(`https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=16/${lat}/${lon}`, '_blank', 'noopener,noreferrer');
    }
  });

  async function boot() {
    try {
      await loadCsrf();
      recordPageView('Login');
      const pending = await request('/api/otp/pending');
      if (pending.ok && pending.data?.pending) {
        pendingUsername = pending.data.username;
        $('otpUsername').value = pendingUsername;
        $('otpIntro').textContent = `Verification code for ${pendingUsername}`;
        showAuth('otp');
        setMessage('otpMessage', 'A verification step is still pending. Enter the code from the delivery channel.', 'info');
        recordPageView('OTP Verification');
        return;
      }
      const me = await request('/api/me');
      if (me.ok && me.data?.user) {
        csrfToken = me.data.csrfToken || csrfToken;
        applyUser(me.data.user);
      } else showAuth('login');
    } catch (error) {
      showAuth('login');
      setMessage('loginMessage', `Cannot connect to CivicGrid. Confirm the server is running at http://localhost:3000. ${error.message || ''}`);
    }
  }
  boot();
})();
